import pandas as pd
import argparse
import os
import matplotlib.pyplot as plt

def analyse_weather(path, start=None, end=None, min_temp=None):

    weather = pd.read_csv(path)

    weather["time"] = pd.to_numeric(weather["time"], errors = "coerce")
    weather["time"] = pd.to_datetime(weather["time"], unit = "ms", errors = "coerce")
    weather = weather.dropna(subset = ["time"])

 #   print(weather["time"].head())


    if start is not None:
        time_start = pd.to_datetime(start)
 #       print(time_start)
        weather = weather[weather["time"] >= time_start] 

    if end is not None:
        time_end = pd.to_datetime(end)
        weather = weather[weather["time"] <= time_end] 
        
    if min_temp is not None:
        weather = weather[weather["temperature_2m"] >= min_temp]

    temp_min = weather["temperature_2m"].min()
    temp_max = weather["temperature_2m"].max()
    temp_avg = weather["temperature_2m"].mean()

    humi_avg = weather["relative_humidity_2m"].mean()
    
    wind_max = weather["wind_speed_10m"].max()

    weather["month"] = weather["time"].dt.to_period("M")
    cc_monthly = weather.groupby("month")["cloud_cover"].mean()

    print("\nThe temperature values:")
    print(" min  |  max   |  avg  ")
    print(f"{temp_min:.3f} | {temp_max:.3f} | {temp_avg:.3f}")

    print(f"\nMean relative humidity at 2 meters above ground: {humi_avg:.3f}")
    print(f"Maximum wind speed at 10 meters above ground: {wind_max:.3f}\n")

    print("Monthly mean cloud cover:")
    for month, value in cc_monthly.items():
        print(f"{month}: {value:.3f}")

    plot_temperature_trend(weather)


def plot_temperature_trend(weather, out_path="results/temperature_2m_trend.png"):
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    # sort by time to make the line nice
    weather = weather.sort_values("time")

    plt.figure()
    plt.plot(weather["time"], weather["temperature_2m"])
    plt.xlabel("Time")
    plt.ylabel("Temperature (°C)")
    plt.title("Temperature at 2m Over Time")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close()

#    print(f"\nPlot saved to {out_path}")


def check_dataset(input):

    try:
        df = pd.read_csv(input)
        required = ["temperature_2m", "relative_humidity_2m", "wind_speed_10m", "cloud_cover", "time"]
        missing = [item for item in required if item not in df.columns]

        if missing:
            return f"Data invalid"
        else:
            return f"Data valid"
    except Exception as e:
        return f"Data check failed: {e}"


def main():
    parser = argparse.ArgumentParser(description = "Weather analysis script")

    parser.add_argument("--input", default = "data/weather_hourly.csv", help = "Path to input CSV file")

    parser.add_argument("--start", help = "Start date")
    parser.add_argument("--end", help = "End date")
    parser.add_argument("--min-temp", type = float , help = "Minimum temperature filter")

    args = parser.parse_args()

#    if args.start is None and args.end is None and args.min_temp is None:
#        parser.error("You must provide at least one filter among the following options : --start, --end, --min-temp")

    analyse_weather(args.input, args.start, args.end, args.min_temp)

if __name__=='__main__':
    main()


